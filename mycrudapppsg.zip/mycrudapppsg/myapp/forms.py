from django import forms
from .models import User

class UserForm(forms.ModelForm):
    liked = forms.MultipleChoiceField(
        choices=User.LIKED_CHOICES,
        widget=forms.CheckboxSelectMultiple(attrs={'class': 'form-check-input'}),
        required=False  # Make it optional if needed
    )
    interest = forms.ChoiceField(
        choices=User.INTEREST_CHOICES,
        widget=forms.RadioSelect(attrs={'class': 'form-check-input'}),
        required=True  # Make it required if needed
    )
    class Meta:
        model = User
        fields = [
            'first_name', 'last_name', 'address', 'city', 'state', 'zip',
            'telephone', 'email', 'dos', 'interest', 'recommendation',
            'liked', 'comments'
        ]
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter First Name'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Last Name'}),
            'address': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Address'}),
            'city': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter City'}),
            'state': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter State'}),
            'zip': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter ZIP Code', 'maxlength': 5}),
            'telephone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter Telephone'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter Email'}),
            'dos': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'interest': forms.RadioSelect(),
            'recommendation': forms.Select(attrs={'class': 'form-control', 'rows': 3}),
            'liked': forms.CheckboxSelectMultiple(),
            'comments': forms.Textarea(attrs={'class': 'form-control', 'rows': 7, 'placeholder': 'Enter Comments'}),
        }
        def __init__(self, *args, **kwargs):
            super(UserForm, self).__init__(*args, **kwargs)
            self.fields['liked'].widget.attrs.update({'class': 'checkbox'})
            self.fields['interest'].widget.attrs.update({'class': 'radio'})