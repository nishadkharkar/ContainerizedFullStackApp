from django.urls import path
from . import views

urlpatterns = [
    path('', views.user_wel, name='user_wel'),  # Redirect base URL to user_list
    path('<int:id>/', views.user_form, name='user_update'),        
    path('user/<int:id>/', views.user_view, name='user_view'),  # Add this for the View button
    path('delete<int:id>/', views.user_delete, name='user_delete'),  # Maps /<id>/ to the user_form view
    path('user/', views.user_form, name='user_form'),  # Maps /user/ to the user_form view
    path('list/', views.user_list, name='user_list'),  # Maps /list/ to the user_list view
]