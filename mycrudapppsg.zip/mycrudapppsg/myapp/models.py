from django.db import models

# Create your models here.
class User(models.Model):
    INTEREST_CHOICES = [
        ('TV', 'TV'),
        ('Friends', 'Friends'),
        ('Internet', 'Internet'),
        ('Others', 'Others'),
    ]
    RECOMMENDATION_CHOICES = [
        ('Very likely', 'Very likely'),
        ('Likely', 'Likely'),
        ('Unlikely', 'Unlikely'),
    ]
    LIKED_CHOICES = [
        ('Sports', 'Sports'),
        ('Dorm Rooms', 'Dorm Rooms'),
        ('Atmosphere', 'Atmosphere'),
        ('Campus', 'Campus'),
        ('Location', 'Location'),
        ('Students', 'Students'),
    ]
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    zip = models.IntegerField()
    telephone = models.CharField(max_length=15)
    email = models.EmailField()
    dos = models.DateField() 
    interest = models.CharField(max_length=20, choices=INTEREST_CHOICES)
    recommendation = models.CharField(max_length=20, choices=RECOMMENDATION_CHOICES) 
    liked = models.JSONField(default=list) # Store multiple choices as a comma-separated string
    comments = models.TextField()