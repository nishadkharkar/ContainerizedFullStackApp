from django.shortcuts import get_object_or_404, redirect, render
from .forms import UserForm
from .models import User

# Create your views here.
def user_wel(request):
    return render(request, 'user/user_wel.html')

def user_list(request):
    context = {'user_list': User.objects.all()}
    return render(request, 'user/user_list.html', context)
  
def user_view(request, id):
    if id == 0:
            # If no ID is provided, create a new form
            form = UserForm()
    else:
            # If an ID is provided, fetch the existing user and populate the form
            user = User.objects.get(pk=id)
            form = UserForm(instance=user)
    return render(request, 'user/user_view.html', {'form': form})

def user_form(request, id=0):
    if request.method == "GET":
        if id == 0:
            # If no ID is provided, create a new form
            form = UserForm()
        else:
            # If an ID is provided, fetch the existing user and populate the form
            user = User.objects.get(pk=id)
            form = UserForm(instance=user)
        return render(request, 'user/user_form.html', {'form': form})
    else:
        if id == 0:
            form = UserForm(request.POST)
        else:
            user = User.objects.get(pk=id)
            form = UserForm(request.POST, instance=user)

        if form.is_valid():
            # Save the form data to the database
            form.save()
            return redirect('user_list')  # Redirect to the user list after saving
        else:
            # If the form is invalid, re-render the form with errors
            return render(request, 'user/user_form.html', {'form': form})


def user_delete(request, id):
    user = User.objects.get(pk=id)
    if request.method == "POST":
        user.delete()
        return redirect('user_list')  # Redirect to the user list after deletion
    return render(request, 'user/user_delete.html', {'user': user})